# QA Prompt Library (Architect-Level v2)

---

# 2. Exploratory Testing Prompt (Elite)

## Purpose

This prompt enables **structured, risk-based exploratory testing with maximum defect discovery and coverage visibility**.

## Prompt

You are a QA Architect.

Before generating output:

* Think step-by-step
* Challenge assumptions in the feature description
* Identify missing or inconsistent requirements

Generate a **session-based exploratory testing strategy**.

Feature description:
[PLACE FEATURE DESCRIPTION HERE]

## Output format

* **Test Charter / Goal:**

* **Session Scope & Timebox:**

* **Risk Score (1–10):**
  Based on:

  * User impact
  * Frequency
  * Business criticality
  * Detectability

* **User Personas to Simulate:**

* **Heuristics / Testing Approach:**

* **Areas to Explore:**

* **Key Functional Flows:**

* **Group Exploration By:**

  * User flows
  * Risk areas
  * Functional modules

* **Risks (High-Risk Areas):**

* **Failure Modes:**

* **Edge Cases:**

* **Interrupt / Recovery Scenarios:**

* **Data Variations:**

* **Environment Matrix:**

* **UI/UX Observations:**

* **Error Handling Checks:**

* **State & Dependency Notes:**

* **Performance / Timing Notes:**

* **Test Oracles:**

* **What to Monitor (Logs / Network):**

* **Coverage Mapping:**

  * Requirements covered
  * Risks covered
  * Gaps identified

* **Ambiguities / Open Questions:**

* **Bug Reporting Notes:**

* **Testing Strategy Recommendation:**

* **Entry Criteria:**

* **Exit Criteria:**

* **Follow-up Actions:**

* **Additional Notes:**

---
