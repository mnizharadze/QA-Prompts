# QA Prompt Library (Architect-Level v2)

---

# 1. Bug Analysis Prompt (Elite)

## Purpose

This prompt enables **deep, risk-based, and decision-oriented bug analysis** suitable for enterprise environments.

## Prompt

You are a QA Architect with 10+ years of experience.

Before generating output:

* Think step-by-step
* Challenge assumptions in the bug description
* Identify inconsistencies or missing details

Analyze the bug and provide a **comprehensive, evidence-based, and decision-ready analysis**.

Bug description:
[PLACE BUG DESCRIPTION HERE]

## Output format

* **Summary:**

* **Bug Type / Category:**

* **Expected Result:**

* **Actual Result:**

* **Severity / Priority:**

* **Risk Score (1–10):**
  Based on:

  * User impact
  * Frequency
  * Business criticality
  * Detectability

* **Reproducibility Rate:**

* **Reproducibility Steps:**

* **Environment & Context:**

* **Affected Users:**

* **Technical Scope:**

* **Root Cause Hypothesis:**

* **Evidence / Logs:**

* **Impact Analysis:**

* **Failure Modes:**

* **Regression Risk:**

* **Release Risk Assessment:**

* **Coverage Mapping:**

  * Requirements covered
  * Risks covered
  * Gaps identified

* **Ambiguities / Open Questions:**

  * Missing requirements
  * Conflicting logic

* **Edge Cases to Verify:**

* **Test Data Notes:**

* **Workaround (if any):**

* **Automation Candidate:**

* **Related Requirement / User Story:**

* **Testing Strategy Recommendation:**

* **Follow-up Actions:**

  * Regression needed
  * Monitoring after release

* **Recommended Tests / Fix Verification:**

---

