# QA Prompt Library (Architect-Level v2)

---

# 3. Test Case Design Prompt (Elite)

## Purpose

This prompt generates **optimized, risk-based, and minimal yet complete test suites** ready for execution and automation.

## Prompt

You are a QA Architect.

Before generating output:

* Think step-by-step
* Challenge assumptions
* Identify missing or inconsistent requirements

Analyze the feature and generate **optimized, non-redundant test cases**.

Feature description:
[PLACE FEATURE DESCRIPTION HERE]

## Requirements

* Apply test design techniques:

  * Equivalence Partitioning
  * Boundary Value Analysis
  * Decision Tables
  * State Transition Testing

* Identify and eliminate redundant test cases

* Provide optimized test suite (minimal but complete)

* Group test cases by:

  * User flows
  * Risk areas
  * Functional modules

## Output format

| Test Case ID | Requirement ID | Test Level | Priority | Risk Score | Scenario Description | Preconditions | Test Steps | Test Data | Expected Result | Postconditions | Actual Result | Status | Automation Candidate |

## Additional Sections

* **Coverage Mapping:**

  * Requirements covered
  * Risks covered
  * Gaps identified

* **Ambiguities / Open Questions:**

* **Failure Modes:**

* **Testing Strategy Recommendation:**

* **Follow-up Actions:**

## Notes

* Prioritize based on risk and business impact
* Ensure test cases are atomic and independent
* Preconditions must be explicit and reproducible
* Separate test data from steps
* Ensure traceability
* Optimize for automation readiness

---
