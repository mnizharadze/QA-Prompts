გაუმჯობესება და რეკომენდაციები:

# Bug Analysis Prompt

✅ რა აქვს უკვე კარგად

ეს ნაწილი ფაქტობრივად სწორად არის დაფარული:

✔ Structured thinking (sections)
✔ Root cause mindset
✔ Risk & regression awareness
✔ Test thinking (edge cases, data)
✔ Fix verification

👉 ანუ: functional QA mindset ✔

❗ რა აკლია (რაც Architect დონეზე კრიტიკულია)

ახლა ყველაზე მნიშვნელოვანი ნაწილი — რა აკლია რომ გახდეს industry-grade

1. ❌ Missing: Bug Classification / Type

👉 ახლა ყველა ბაგი ერთნაირად განიხილება
მაგრამ რეალურად საჭიროა კატეგორიზაცია:

Functional
UI/UX
Performance
Security
Data integrity
Integration/API
Accessibility

👉 რატომ არის ეს critical:

ეხმარება triage-ს
სწორ გუნდამდე მიდის (frontend/backend/devops/security)

✔ დაამატე:

- **Bug Type / Category:**
2. ❌ Missing: Actual vs Expected Result

👉 ეს არის QA-ს ბირთვი — და საერთოდ არ არის 😅

✔ უნდა იყოს ცალკე სექციებად:

- **Expected Result:**
- **Actual Result:**

👉 Without this → analysis არის “interpretation”, არა ფაქტი

3. ❌ Missing: Logs / Evidence / Observability

Senior QA არასოდეს აანალიზებს ბაგს მტკიცებულებების გარეშე

✔ დაამატე:

- **Evidence / Logs:**
  - Console logs
  - Network responses
  - Screenshots / videos
  - Error messages

👉 ეს არის ის, რაც dev-ს რეალურად ეხმარება

4. ❌ Missing: Scope of Impact (Technical)

Impact Analysis გაქვს, მაგრამ უფრო business-centric არის

დააკლია technical layer:

✔ დაამატე:

- **Technical Scope:**
  - Affected services / APIs
  - Database impact
  - Third-party integrations
5. ❌ Missing: Reproducibility Rate

👉 “works sometimes” vs “always” არის huge difference

✔ დაამატე:

- **Reproducibility Rate:**
  - Always / Intermittent / Rare
6. ❌ Missing: Workaround (Critical for real teams)

👉 Production bugs without workaround = escalation

✔ დაამატე:

- **Workaround (if any):**
7. ❌ Missing: User Persona / Affected Segment

👉 ყველა მომხმარებელზე მოქმედებს თუ არა?

✔ დაამატე:

- **Affected Users:**
  - All users / specific roles / regions / devices
8. ❌ Missing: Release Risk / Go-Live Decision Input

👉 ეს უკვე architect დონეა

✔ დაამატე:

- **Release Risk Assessment:**
  - Blocker / Can ship with fix later / Needs hotfix
9. ❌ Missing: Automation Potential

👉 თანამედროვე QA = automation thinking

✔ დაამატე:

- **Automation Candidate:**
  - Should this be covered by automated tests? (Yes/No + type)
10. ❌ Missing: Traceability (Requirements կապი)

👉 enterprise გარემოში ეს MUST არის

✔ დაამატე:

- **Related Requirement / User Story:**
🔥 როგორ გამოიყურება IDEAL VERSION (გაუმჯობესებული სტრუქტურა)

აი upgraded version (ეს უკვე შეგიძლია სტუდენტს დაუბრუნო როგორც “gold standard”):

🔧 დამატებული Output format
- **Summary:**
- **Bug Type / Category:**
- **Expected Result:**
- **Actual Result:**

- **Severity / Priority:**
- **Reproducibility Rate:**
- **Reproducibility Steps:**

- **Environment & Context:**
- **Affected Users:**
- **Technical Scope:**

- **Root Cause Hypothesis:**
- **Evidence / Logs:**

- **Impact Analysis:**
- **Regression Risk:**
- **Release Risk Assessment:**

- **Edge Cases to Verify:**
- **Test Data Notes:**

- **Workaround (if any):**
- **Automation Candidate:**
- **Related Requirement / User Story:**

- **Recommended Tests / Fix Verification:**


# Exploratory Testing Prompt


✅ რა აქვს ძალიან კარგად

ეს prompt უკვე კარგ საფუძველზე დგას:

✔ აქვს charter-based thinking (ძალიან კარგი)
✔ მოიცავს risk-based მიდგომას
✔ ეხება UI/UX + data + edge cases
✔ ითვალისწინებს state & dependencies
✔ არ არის rigid → exploratory mindset სწორია

👉 შეფასება ამ ეტაპზე:
8 / 10 (strong senior-level baseline)

❗ რა აკლია (Architect თვალით)

ახლა მოდის ყველაზე მნიშვნელოვანი ნაწილი — ის რაც რეალურ გუნდებში exploratory-ს ძალიან აძლიერებს

1. ❌ Missing: Session-Based Testing Structure (SBTM)

👉 exploratory testing = chaotic exploration ❌
👉 სწორად = time-boxed sessions + accountability ✔

✔ უნდა დაემატოს:

- **Session Scope & Timebox:**
  - რამდენ ხანს გრძელდება სესია (e.g. 60–90 min)

👉 რატომ:

ზრდის ფოკუსს
measurable ხდება testing effort
2. ❌ Missing: Heuristics / Testing Models

👉 ახლა checklist არის “რა ვტესტოთ”
მაგრამ აკლია “როგორ ვიფიქროთ”

Senior QA იყენებს heuristics-ს:

SFDPOT (Structure, Function, Data, Platform, Operations, Time)
CRUD
Tours (FedEx tour, Landmark tour, etc.)

✔ დაამატე:

- **Heuristics / Testing Approach:**
  - Suggested models (SFDPOT, CRUD, User Journeys, etc.)
3. ❌ Missing: User Personas / Usage Patterns

👉 exploratory უნდა იყოს user-centric, არა მხოლოდ feature-centric

✔ დაამატე:

- **User Personas to Simulate:**
  - New user / returning user / admin / edge user
4. ❌ Missing: Test Oracles (როგორ ვხვდები რომ რაღაც არასწორია?)

👉 ეს არის ერთ-ერთი ყველაზე underestimated ნაწილი QA-ში

✔ დაამატე:

- **Test Oracles:**
  - რას ეყრდნობა ტესტერი (requirements, UX patterns, კონკურენტები, intuition)
5. ❌ Missing: Bug Logging Guidance

👉 exploratory-ს დროს ყველაზე დიდი პრობლემა:
➡️ ტესტერი პოულობს რაღაცას, მაგრამ ცუდად აღწერს

✔ დაამატე:

- **Bug Reporting Notes:**
  - რა უნდა დაფიქსირდეს (steps, logs, ვიდეო, data)
6. ❌ Missing: Entry / Exit Criteria

👉 როდის ვიწყებთ და როდის ვამთავრებთ?

✔ დაამატე:

- **Entry Criteria:**
- **Exit Criteria:**
7. ❌ Missing: Coverage Tracking

👉 exploratory ხშირად ხდება “ვიტესტე ცოტა ყველაფერი”

მაგრამ:
👉 Architect mindset = “რა დავფარე?”

✔ დაამატე:

- **Coverage Notes:**
  - რომელი flows / modules გაიტესტა
8. ❌ Missing: Environment Matrix Thinking

👉 ახლა environment არის implicit

✔ დაამატე:

- **Environment Matrix:**
  - Browsers / devices / OS combinations
9. ❌ Missing: Interruption / Recovery Scenarios

👉 რეალურ ცხოვრებაში user არ არის “happy flow robot”

✔ დაამატე:

- **Interrupt Scenarios:**
  - Page refresh, ქსელის გათიშვა, back button, session timeout
10. ❌ Missing: Observability / Debugging Awareness

👉 exploratory QA უნდა იყოს “mini-debugger”

✔ დაამატე:

- **What to Monitor:**
  - Network calls, console, logs, API responses
🔥 IDEAL VERSION (Upgraded Structure)

აი როგორ გადააქცევ ამას top-tier exploratory prompt-ად

🔧 გაუმჯობესებული Output format
- **Test Charter / Goal:**
- **Session Scope & Timebox:**

- **User Personas to Simulate:**
- **Heuristics / Testing Approach:**

- **Areas to Explore:**
- **Key Functional Flows:**

- **Risks (High-Risk Areas):**
- **Edge Cases:**
- **Interrupt / Recovery Scenarios:**

- **Data Variations:**
- **Environment Matrix:**

- **UI/UX Observations:**
- **Error Handling Checks:**

- **State & Dependency Notes:**
- **Performance / Timing Notes:**

- **Test Oracles:**
- **What to Monitor (Logs / Network):**

- **Coverage Notes:**
- **Bug Reporting Notes:**

- **Entry Criteria:**
- **Exit Criteria:**

- **Additional Notes:**




# Test Case Design Prompt


✅ რა აქვს კარგად

ეს ნაწილი სწორად არის დაფარული:

✔ Positive / Negative / Edge / Boundary coverage
✔ Functional flows thinking
✔ Validation & error handling
✔ Security touch (good sign)
✔ Dependencies awareness

👉 ანუ:
functional completeness ✔

❗ მთავარი პრობლემა (ძალიან მნიშვნელოვანი)

👉 ეს prompt ქმნის “test case list”-ს
მაგრამ არ ქმნის “test design strategy”-ს

და ეს არის მთავარი gap.

❗ რა აკლია (Architect დონეზე)
1. ❌ Missing: Test Case Type / Level

👉 ყველა ტესტი ერთნაირად არის წარმოდგენილი

რეალურად საჭიროა დაყოფა:

Smoke
Sanity
Regression
Integration
E2E

✔ დაამატე:

- **Test Level / Type:**
2. ❌ Missing: Test Priority

👉 ყველა ტესტის გაშვება ყოველთვის შეუძლებელია

✔ დაამატე ცხრილში:

| Priority (P0/P1/P2) |

👉 ეს არის critical for:

release decisions
CI/CD pipelines
3. ❌ Missing: Test Data Separation

👉 ახლა data არის implicit

Senior QA:
👉 data = დამოუკიდებელი layer

✔ დაამატე:

| Test Data |
4. ❌ Missing: Postconditions

👉 რა ხდება ტესტის შემდეგ?

✔ დაამატე:

| Postconditions |
5. ❌ Missing: Actual Result / Execution Readiness

👉 ეს test case არის design-only
არ არის execution-ready

✔ დაამატე:

| Actual Result |
| Status (Pass/Fail) |
6. ❌ Missing: Traceability (VERY IMPORTANT)

👉 enterprise QA-ში MUST

✔ დაამატე:

| Requirement / User Story ID |
7. ❌ Missing: Automation Potential

👉 modern QA = automation-first thinking

✔ დაამატე:

| Automation Candidate (Yes/No) |
8. ❌ Missing: Risk-Based Thinking

👉 ახლა ყველაფერი equally მნიშვნელოვანია ❌

✔ დაამატე prompt-ში:

- Identify high-risk scenarios and prioritize them
9. ❌ Missing: Precondition Quality

👉 ხშირად ხდება generic:

❌ "User is logged in"
✔ უნდა იყოს კონკრეტული:

role
state
data setup

👉 შეგიძლია enforce:

- Preconditions must be explicit and reproducible
10. ❌ Missing: Test Design Techniques (critical gap)

👉 ეს არის ყველაზე დიდი პრობლემა

ახლა prompt ამბობს:
👉 “დაწერე ტესტები”

მაგრამ არ ამბობს:
👉 “როგორ დააპროექტო”

✔ დაამატე:

- Apply test design techniques such as:
  - Equivalence Partitioning
  - Boundary Value Analysis
  - Decision Tables
  - State Transition Testing
🔥 IDEAL VERSION (Upgraded Table)

აი როგორ უნდა გამოიყურებოდეს უკვე production-grade test case format

🔧 გაუმჯობესებული Output format
| Test Case ID |
| Requirement ID |
| Test Level |
| Priority |
| Scenario Description |
| Preconditions |
| Test Steps |
| Test Data |
| Expected Result |
| Postconditions |
| Actual Result |
| Status |
| Automation Candidate |
🔥 Prompt-ის გაუმჯობესება (მნიშვნელოვანი დამატება)

აუცილებლად დაამატე ეს ნაწილი:

Additionally:
- Prioritize test cases based on risk and business impact
- Avoid redundant test cases by optimizing coverage
- Clearly separate test data from steps
- Ensure each test case is atomic and independent
- Apply appropriate test design techniques



Prompt Types
1. Bug Analysis Prompt

Focus:

Root cause hypothesis
Risk evaluation
Impact analysis
Release decision support

Outcome:
👉 Clear, actionable, and decision-ready bug reports

2. Exploratory Testing Prompt

Focus:

Risk-based exploration
Heuristics-driven testing
Session-based execution
Coverage tracking

Outcome:
👉 Structured exploratory testing with high defect discovery rate

3. Test Case Design Prompt

Focus:

Optimized test suite generation
Risk prioritization
Redundancy elimination
Automation readiness

Outcome:
👉 Minimal, high-quality, production-ready test cases

Key Principles
✔ Risk over completeness

Not everything needs to be tested — only what matters most

✔ Quality over quantity

Fewer, smarter test cases outperform large redundant sets

✔ Thinking over execution

QA is decision-making, not just validation

✔ Coverage visibility

Always know what is tested and what is not

✔ Continuous improvement

Every bug and test improves future coverage

Maturity Model
Level	Description
Junior	Basic test cases
Middle	Structured coverage
Senior	Risk-based testing
Architect	Optimization + decision-making
Elite	Intelligent QA system
Usage

These prompts can be used with:

ChatGPT
Cursor
Codex
Any AI-assisted QA workflow
Final Thought

This library transforms QA from:

❌ Test execution
➡️
✅ Quality Engineering & Decision System

